import React from "react";

const About = () => {
    return (
        <div className="section food-menu" id="food-menu" style="background-color:rgb(255, 255, 255);">
        <div className="">
          <h1 className="h2 section-title">
            Why choose Ileero Remit
          </h1>
    
          <p className="section-text">
            Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut
          </p>
          <ul className="food-menu-list">
    
            <li>
              <div className="food-menu-card">
    
                <h3 className="h3 card-title">Fastest way to send money online</h3>                 
                 <p style="font-size:14px;" align="left">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut</p>
    
    
              </div>
            </li>
    
            
            <li>
              <div className="food-menu-card">
    
                <h3 className="h3 card-title">Fastest way to send money online</h3>                 
                <p style="font-size:14px;" align="left">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut</p>
    
              </div>
            </li>
    
            <li>
              <div className="food-menu-card">
                <h3 className="h3 card-title">Fastest way to send money online</h3>                 
                <p style="font-size:14px;" align="left">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut</p>
              </div>
            </li>
    
            <li>
              <div className="food-menu-card">
                <h3 className="h3 card-title">Fastest way to send money online</h3>                 
                <p style="font-size:14px;" align="left">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut</p>                
                </div>
            </li>
    
          
            <li>
              <div className="food-menu-card">
                <h3 className="h3 card-title">Fastest way to send money online</h3>                 
                <p style="font-size:14px;" align="left">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut</p>                
                </div>
            </li>
    
            
            <li>
              <div className="food-menu-card">
                <h3 className="h3 card-title">Fastest way to send money online</h3>                 
                <p style="font-size:14px;" align="left">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut</p>                
                </div>
            </li>
          </ul>
        </div>
      </div>
    )
}

export default About;